import Foundation

struct FoodItem: Identifiable {
    let id = UUID()
    let imageName: String
    let name: String
    let price: Double
}
