import SwiftUI

struct StartView: View {
    @Binding var isLoggedIn: Bool
    @Binding var username: String
    @Binding var defaultDropoff: String
    @Binding var ghUsername: String
    @Binding var isWorker: Bool
    @State private var password = ""
    @State private var isCreatingAccount = false
    @State private var loginError: String? = nil
    @State private var isCreatingBypass = false
    
    @State private var isLoading = false // New state for loading screen

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.orange, .yellow],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(alignment: .center) {
                
                Spacer()
                
                Image("logo_image_4")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 350, height: 300)
                
                Spacer()
                
               Text("Welcome to GreyhoundHub")
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.top, 40)
                        //.padding(.horizontal, 20)
                        .foregroundColor(.white)
                
                Text("Enter your login information below.")
                    .font(.title3)
                    .foregroundColor(.white)
                    .lineLimit(nil)
                
                Spacer()
                
                TextField("Username", text: $username)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal, 20)
                    .padding(.vertical, 5)
                
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal, 20)
                    .padding(.vertical, 5)

                if let error = loginError {
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                }

                Spacer()
                
                Button(action: {
                    loginAction()
                }) {
                    Text("Login")
                }
                .font(.title)
                .foregroundColor(.white)
                .padding()
                .background(Color.orange)
                .cornerRadius(5)
                
                Spacer()
                
                Text("Don't have an account yet?")
                    .foregroundColor(.white)
                    .padding(.horizontal, 10)
                
                Text("Create New Account")
                    .foregroundColor(.white)
                    .underline()
                    .padding(.horizontal, 10)
                    .onTapGesture {
                        isCreatingAccount = true
                    }
                    .sheet(isPresented: $isCreatingAccount) {
                        CreateAccountView(creatingAccount: $isCreatingAccount)
                    }
            }
            
            // Loading screen
            if isLoading {
                Color.white.opacity(0.7)
                    .ignoresSafeArea()
                    .overlay(
                        Text("Logging in...")
                            .font(.headline)
                            .foregroundColor(.black)
                    )
            }
        }
    }
    
    func loginAction() {
        // Show loading screen
        isLoading = true
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            isLoading = false // Simulating login delay with DispatchQueue
            // Example of successful login
            isLoggedIn = true
            isWorker = false
        }
    }
}


