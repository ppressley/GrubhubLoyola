import SwiftUI
import CoreLocation
import Foundation


struct ContentView: View {
    @State private var isLoggedIn = false
    @State private var username: String = ""
    @State private var defaultDropoff: String = ""
    @State private var ghUsername: String = ""
    @State private var isWorker = false
    @State private var orderName: String = ""
    @State var cost: Double = 0
    

    
    var body: some View {
        if(isLoggedIn && !isWorker){
            CreateBypassView(isLoggedIn: $isLoggedIn, username: $username, defaultDropoff: $defaultDropoff, ghUsername: $ghUsername, isWorker: $isWorker, orderName: $orderName, cost: $cost)
        }
        else if (isLoggedIn && isWorker){
            WorkerHomeView(isLoggedIn: $isLoggedIn, username: $username, defaultDropoff: $defaultDropoff, ghUsername: $ghUsername, isWorker: $isWorker, locationName: "loyola", orderName: $orderName)
        }
        else{
            StartView(isLoggedIn: $isLoggedIn, username: $username, defaultDropoff: $defaultDropoff, ghUsername: $ghUsername, isWorker: $isWorker)
        }
    }
}


class PostViewModel: ObservableObject {
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
