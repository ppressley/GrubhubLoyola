import Foundation
import SwiftUI

struct PaymentView: View {
    @State private var isPaymentSuccessful = false
    @Binding var isShowingPaymentView: Bool
    @Binding var isShowingChoices: Bool
    @Binding var cost: Double
    @State  var deliveryFee: Double = 3.50
    @State  var fees: Double = 2.00
   
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.orange, .yellow],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack {
                if isPaymentSuccessful {
                    Text("Payment Successful!")
                } else {
                    Text("Digital Receipt")
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.vertical, 5)
                    
                    VStack(alignment: .leading, content: {
                        Text("Subtotal: $\(String(format: "%.2f", cost))")
                            .font(.body)
                            .padding(.vertical, 5)
                                            
                        Text("Delivery-Fee: $\(String(format: "%.2f", deliveryFee))")
                            .font(.body)
                            .padding(.vertical, 5)
                                            
                        Text("Fees & Estimated Taxes: $\(String(format: "%.2f", fees))")
                            .font(.body)
                            .padding(.vertical, 5)
                                            
                        let total = cost + deliveryFee + fees
                        Text("Total: $\(String(format: "%.2f", total))")
                            .font(.body)
                            .fontWeight(.bold)
                            .padding(.vertical, 5)
                    })
                                        
                    Button("Pay with Apple Pay") {
                        // Simulate payment processing
                        simulatePayment()
                        isShowingChoices = false
                        isShowingPaymentView = false
                    }
                    .padding()
                    .font(.title3)
                    .foregroundColor(.orange)
                    .background(.white)
                    .cornerRadius(100)
                }
            }
            .foregroundColor(.white)
            .padding(25)
            .border(Color.orange, width: 4)
        }
    }
    func simulatePayment() {
       
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            // Update state to simulate success
            self.isPaymentSuccessful = true
        }
    }
}
