import SwiftUI

struct StartView: View {
    
    @State private var isLoginViewPresented = false
    @State private var isWorkerLoginViewPresented = false
    @Binding var isLoggedIn: Bool
    @Binding var username: String
    @Binding var defaultDropoff: String
    @Binding var ghUsername: String
    @Binding var isWorker: Bool
    
    var body: some View {
        VStack {
            ZStack {
                LinearGradient(
                    colors: [.orange, .yellow],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack {
                    HStack {
                        Spacer()
                        Text("GreyhoundGrub")
                            .font(.system(size: 32))
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding(.top, 40)
                        
                        Spacer()
                        
                        Button(action: {
                            isWorkerLoginViewPresented = true
                        }) {
                            Image(systemName: "envelope.badge.fill")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white)
                                .padding()
                        }
                        .padding(.top, 20)
                        .padding(.leading, 20)
                        .sheet(isPresented: $isWorkerLoginViewPresented) {
                            WorkerLoginView(username: $username, isLoggedIn: $isLoggedIn, showingLoginSheet: $isWorkerLoginViewPresented, worker: $isWorker)
                        }
                        
                        Spacer()
                    }
                    
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                }
            }
            
            HStack {
                Button(action: {
                    
                }) {
                    Image(systemName: "person.2.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 40, height: 40)
                        .foregroundColor(.white)
                        .padding()
                }
                .padding(.top, 20)
                .padding(.leading, 20)
                

                Spacer()
                
                Button(action: {
                     
                }) {
                    Image(systemName: "envelope.badge.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 40, height: 40)
                        .foregroundColor(.white)
                        .padding()
                }
                .padding(.top, 20)
                .padding(.leading, 20)
                
                Spacer()
                
                Button(action: {
                    isLoginViewPresented = true
                }) {
                    Image(systemName: "person.crop.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 40, height: 40)
                        .foregroundColor(.white)
                        .padding()
                }
                .padding(.top, 20)
                .padding(.leading, 20)
                .sheet(isPresented: $isLoginViewPresented) {
                    LoginView(username: $username, defaultDropoff: $defaultDropoff, ghUsername: $ghUsername, isLoggedIn: $isLoggedIn, showingLoginSheet: $isLoginViewPresented, isWorker: $isWorker)
                }
            }
            .padding(.bottom, 20) // Adjust bottom padding as needed
            .background(Color.black.opacity(0.5)) // Add background color for the bottom bar
            
        }
        .edgesIgnoringSafeArea(.bottom) // Ensure bottom bar is not overlapped by safe area
    }
}

