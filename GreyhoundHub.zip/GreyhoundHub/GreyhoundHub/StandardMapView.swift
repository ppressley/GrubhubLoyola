import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI


struct StandardMapView: View {
    @StateObject var locationManager = LocationManager()
    @State var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172),
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    )
    @State var testMarker = CustomAnnotation(id: UUID(), coordinate: CLLocationCoordinate2D(latitude: 39.34652606069628, longitude: -76.62186017151022))
    @Binding var isShowingMap: Bool
    
    @State private var annotations: [CustomAnnotation] = []
    
    var body: some View {
        VStack {
            if let location = locationManager.location {
                Map(coordinateRegion: $region, interactionModes: .all, showsUserLocation: true, userTrackingMode: .constant(.follow), annotationItems: annotations) { annotation in
                    MapAnnotation(coordinate: annotation.coordinate) {
                        Image(systemName: "mappin.and.ellipse")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 40)
                            .foregroundColor(.red)
                    }
                }
            }
            else {
                ProgressView()
                    .scaleEffect(1.74)
                    .tint(.green)
            }
        }
    }
    
    
    class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
        let manager = CLLocationManager()
        @Published var location: CLLocationCoordinate2D?
        @Published var region: MKCoordinateRegion?
        
        override init() {
            super.init()
            manager.delegate = self
            requestLocation()
            
            // For Preview Testing Comment This Out
            location = CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172)
        }
        
        func requestLocation() {
            manager.requestWhenInUseAuthorization()
            manager.requestLocation()
        }
        
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            guard let location = locations.first?.coordinate else { return }
            self.location = location
            self.region = MKCoordinateRegion(
                center: location,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            )
        }
        
        func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
            print(error)
        }
    }
}

