import SwiftUI

@main
struct GreyhoundHubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
